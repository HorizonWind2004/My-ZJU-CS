### Enviroment:

g++ version: Apple clang version 15.0.0 (clang-1500.3.9.4)

### Usage:

use this to compile:

```shell
g++ fraction.cpp fraction_test.cpp -std=c++11 -o main
./main
```