g++ -std=c++11 diary.cpp pdadd.cpp -o pdadd
g++ -std=c++11 diary.cpp pdlist.cpp -o pdlist
g++ -std=c++11 diary.cpp pdremove.cpp -o pdremove
g++ -std=c++11 diary.cpp pdshow.cpp -o pdshow