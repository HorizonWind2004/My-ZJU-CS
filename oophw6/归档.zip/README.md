# 编译方法

```shell
g++ test.cpp -o main -std=c++11
./main
```
